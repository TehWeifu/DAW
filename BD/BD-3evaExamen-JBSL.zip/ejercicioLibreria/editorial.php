<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Editorial</title>
</head>
<body>
<?php
include_once "./resources/dependencies/conexion.php";
/** @var PDO $connexion */

const DELETE = 1;
const EDIT = 2;

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (isset($_GET['mode']) && $_GET['mode'] == DELETE) {
        $idx = $_GET['indx'];

        $connexion->query("DELETE FROM editorial WHERE id = $idx") or die($connexion->errorInfo());
    } elseif (isset($_GET['mode']) && $_GET['mode'] == EDIT) {
        $idx = $_GET['indx'];

        $sql = $connexion->query("SELECT * FROM editorial WHERE id = $idx") or die($connexion->errorInfo());
        $tmpRecord = $sql->fetch(PDO::FETCH_ASSOC);
        $name = $tmpRecord['nombre'];

        print "<form method='post' action='" . $_SERVER['PHP_SELF'] . "'>";
        print "<p><label>id_editorial: <input type='text' readonly value='$idx' name='idx' ></label></p>";
        print "<p><label>Nombre: <input type='text' name='name' value='$name' ></label></p>";
        print "<p><input type='submit' name='edit' value='Editar'></p>";
        print "</form>";
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['edit'])) {
        $idx = $_POST['idx'];
        $name = $_POST['name'];

        $connexion->query("UPDATE editorial SET nombre='$name' WHERE id=$idx") or die($connexion->errorInfo());

    } else {
        $user_nameegory = $_POST['name'];

        $insert_sql = $connexion->query("INSERT INTO editorial VALUES (null, '$user_nameegory')") or die($connexion->errorInfo());
    }
}
$query = "SELECT * FROM editorial";
if (isset($_GET['sort'])) {
    $field_sort = $_GET['sort'];
    $query .= " ORDER BY $field_sort";
    if (isset($_GET['asc'])) {
        $query .= " ASC";
    } else {
        $query .= " DESC";
    }
}
$sql = $connexion->query($query) or die($connexion->errorInfo());

$fields = array_map(function ($el) {
    return $el['Field'];
}, $connexion->query("DESCRIBE editorial")->fetchAll(PDO::FETCH_ASSOC));

print "<table border='1'>";
print "<tr>";
foreach ($fields as $field) {
    print "<th>$field <a href='" . $_SERVER['PHP_SELF'] . "?sort=$field&asc" . "'>↑</a> " .
        "<a href='" . $_SERVER['PHP_SELF'] . "?sort=$field&des" . "'>↓</a> </th>";
}
print "</tr>";


while ($fila = $sql->fetch(PDO::FETCH_NUM)) {
    $tmp_idx = $fila[0];

    print "<tr><td>";
    print(implode("</td><td>", $fila));

    print "</td><td><a href='" . $_SERVER['PHP_SELF'] . "?mode=" . DELETE . "&indx=$tmp_idx" . "'>Eliminar</a>";
    print "</td><td><a href='" . $_SERVER['PHP_SELF'] . "?mode=" . EDIT . "&indx=$tmp_idx" . "'>Editar</a>";
    print "</td></tr>";
}
print "</table>";

if (!isset($_GET['mode'])) {
    ?>

    <form action="<?= $_SERVER['PHP_SELF'] ?>" method="post">
        <p>Nueva editorial</p>
        <label>
            Nombre: <input type="text" name="name">
        </label>
        <input type="submit" name="enviar" value="Agregar">
    </form>
<?php } else { ?>
    <hr>
    <p><a href="<?= $_SERVER['PHP_SELF'] ?>"> Añadir registro</a></p>
<?php } ?>

<hr>
<p><a href="./index.php"> Volver al índice</a></p>

</body>
</html>
