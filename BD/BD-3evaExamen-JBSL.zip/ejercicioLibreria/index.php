<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Index Libreria</title>
</head>
<body>
<ul>
    <li><a href="./libros.php">Libros</a></li>
    <li><a href="./categorias.php">Categorias</a></li>
    <li><a href="./editorial.php">Editorial</a></li>
</ul>

<?php if (isset($_POST['sub'])) {
    print "<p>Logueado como</p>";
    print sprintf("Alumno/a: <strong>%s %s</strong>", $_POST['name'], $_POST['lastNames']);
    print "<p><a href='" . $_SERVER['PHP_SELF'] . "'>Volver al log-in</a></p>";
} else { ?>
    <p>Log-in</p>
    <form method="post" action="<?= $_SERVER['PHP_SELF'] ?>">
        <p>
            <label>
                Nombre: <input type="text" name="name">
            </label>
        </p>
        <p>
            <label>
                Apellidos: <input type="text" name="lastNames">
            </label>
        </p>
        <input type="submit" name="sub" value="Log-in">
    </form>
<?php } ?>

</body>
</html>